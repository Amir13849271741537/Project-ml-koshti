import streamlit as st
import joblib
import numpy as np

# لود مدل‌ها
model = joblib.load("text_model.pkl")
label_encoder = joblib.load("label_encoder.pkl")

st.set_page_config(page_title="Wrestling Talent Finder", page_icon="🤼")

st.title("🤼 سیستم استعداد یابی کشتی")
st.write("اطلاعات بدنی خود را وارد کنید تا نوع مناسب کشتی پیشنهاد شود.")

# ورودی‌ها
weight = st.number_input("وزن (کیلوگرم)", 40.0, 150.0, 70.0)
height = st.number_input("قد (سانتی‌متر)", 140.0, 210.0, 175.0)
age = st.number_input("سن", 10, 50, 20)
body_fat = st.number_input("درصد چربی بدن", 3.0, 40.0, 15.0)
strength = st.slider("قدرت بدنی (از 1 تا 10)", 1, 10, 5)
medal = st.selectbox("سابقه مدال دارد؟", ["خیر", "بله"])

medal_value = 1 if medal == "بله" else 0

if st.button("پیشنهاد رشته"):
    input_data = np.array([[weight, height, age, body_fat, strength, medal_value]])
    pred = model.predict(input_data)
    result = label_encoder.inverse_transform(pred)[0]
    st.success(f"🏆 رشته پیشنهادی برای شما: {result}")
